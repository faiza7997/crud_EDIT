export const data=[
    { id:1, name : 'Farangiz Ergashbaeva'},
    { id:2, name : 'Karimov Islom'},
    { id:3, name : 'Samandar Yakhyaev'},
    { id:4, name : 'Gulamov Olimjon'},
    { id:5, name : 'Ormonova Gulhayo'},
    
]

