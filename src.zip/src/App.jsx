 import { Component } from 'react';
import './App.css';
import {data} from './data'

class App extends Component {
constructor(props){
  super(props);
  this.state={
   subject:data,
   search:'',
   select:'id',
   name: '',
   value: ''
  //  id: ''
  }
}

  render(){
    const onSearch = (e) =>{
      const {value}=e.target;
      const res = data.filter((item)=>item[this.state.select].toString().toLowerCase().includes(value.toString().toLowerCase()))
       this.setState({subject: res})
    }


    const onSelect =(e)=>{
      const {value}=e.target;
      this.setState({select: value})
    }



    const onEnter=(e)=>{
      const {value}=e.target;
      this.setState({name:value})
    }


    const onAdd=(e)=>{
      const newUser={
        id:this.state.subject.length+1,
        name:this.state.name
      }
      this.setState({
        subject:[...this.state.subject, newUser],
        name:''
      })
    }
    
    const  onDelete=(id)=>{
      let res = this.state.subject.filter((value)=> value.id!==id)
      this.setState({subject:res})

    }
    const onChange=(e)=>{
      const {value,name }= e;
      this.setState({name:value})
    }
    const onEdit=(value)=>{
      this.setState({selected:value})
      
    }


  return (
    <div className="App">
      <div className="app">
      <h3>G13 students list</h3>
   
        <input className='input'  type="text" placeholder='Search...' onChange={onSearch}/>
          <select className='select' onChange={onSelect}>
            <option value="id">ID</option>
            <option value="name">Name</option>
          </select>
          <div className="data-wrapper">
          <table >
            <tbody>
              {this.state.subject.map(({id,name})=>{
                return (
                   <tr>
                    <td className='data-id' >{id}</td>
                    <td className='data-name'>{name}</td>
                    <td className='data-btn'>
                      <button onClick={()=>onDelete(id)}>delete</button>
                    </td>
                    <td  className='data-edit'>
                      {
                        this.setState.selected.id ===value.id?<input onChange={()=>onChange} value={this.state.selected.name} type='text' /> :value.name
                      }
                    
                      { 
                       this.state.sected.id===value.id ? <button>Save</button> : <button onClick={() =>onEdit(value)}>Edid</button>
                      }

                      
                    </td>
                   </tr>
                )
                })
              }
            </tbody>
          </table>
          </div>
          <div className="add-wrapper">
            <input value={this.state.name} className='input' type="text" placeholder='Add sudent' onChange={onEnter} />
            <button className="add-data" onClick={onAdd}>Add</button>
        </div>
        </div>
     </div>
  );
 }
}
export default App;
